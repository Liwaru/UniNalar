<?php

namespace Tests\Support;

use App\Models\Dosen;
use App\Models\KelasKuliah;
use App\Models\Krs;
use App\Models\KrsDetail;
use App\Models\Mahasiswa;
use App\Models\MataKuliah;
use App\Models\ProgramStudi;
use App\Models\Semester;
use App\Models\User;

final class MysqlFixtures
{
    public static function make(int $students = 1, ?int $capacity = 30): array
    {
        $tag = strtoupper(bin2hex(random_bytes(4)));
        $program = ProgramStudi::create(['kode' => 'QA'.$tag, 'nama' => 'QA Terisolasi '.$tag, 'jenjang' => 'S1', 'aktif' => true]);
        Semester::query()->where('aktif', true)->update(['aktif' => false]);
        $year = 2026 + Semester::count();
        $semester = Semester::create(['kode' => 'QA'.$tag, 'tahun_ajaran' => $year.'/'.($year + 1), 'periode' => 1, 'aktif' => true,
            'krs_mulai_pada' => now('Asia/Jakarta')->subDay()->format('Y-m-d H:i:s'), 'krs_selesai_pada' => now('Asia/Jakarta')->addDay()->format('Y-m-d H:i:s')]);
        $lecturerUser = User::factory()->create(['level' => 2]);
        $lecturer = Dosen::create(['user_id' => $lecturerUser->id, 'nama' => 'Dosen QA '.$tag, 'program_studi_id' => $program->id, 'aktif' => true]);
        $course = MataKuliah::create(['program_studi_id' => $program->id, 'kode' => 'QA'.$tag, 'nama' => 'Mata Kuliah QA '.$tag, 'sks' => 3]);
        $class = KelasKuliah::create(['mata_kuliah_id' => $course->id, 'semester_id' => $semester->id, 'dosen_id' => $lecturer->id, 'kode_kelas' => 'A', 'kapasitas' => $capacity]);
        $admin = User::factory()->create(['level' => 3]);
        $users = collect();
        $profiles = collect();
        foreach (range(1, $students) as $number) {
            $user = User::factory()->create(['level' => 1]);
            $users->push($user);
            $profiles->push(Mahasiswa::create(['user_id' => $user->id, 'nim' => 'QA'.$tag.$number, 'nama' => 'Mahasiswa QA '.$tag.$number, 'angkatan' => 2026, 'program_studi_id' => $program->id]));
        }

        return compact('program', 'semester', 'lecturerUser', 'lecturer', 'course', 'class', 'admin', 'users', 'profiles');
    }

    public static function detail(array $data, int $student = 0, string $status = 'disetujui'): KrsDetail
    {
        $krs = Krs::create(['mahasiswa_id' => $data['profiles'][$student]->id, 'semester_id' => $data['semester']->id, 'status' => $status]);

        return KrsDetail::create(['krs_id' => $krs->id, 'kelas_kuliah_id' => $data['class']->id]);
    }
}
