<?php

namespace Tests\Feature;

use App\Models\ProgramStudi;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminFormStateTest extends TestCase
{
    use RefreshDatabase;

    public function test_unchecked_active_state_survives_validation_failure(): void
    {
        $admin = User::factory()->create(['level' => 3]);
        $program = ProgramStudi::create(['kode' => 'TI', 'nama' => 'Teknologi Informasi', 'jenjang' => 'S1', 'aktif' => true]);
        $edit = route('dashboard.admin-akademik.program-studi.edit', $program);
        $this->actingAs($admin)->from($edit)->put(route('dashboard.admin-akademik.program-studi.update', $program), [
            'kode' => 'TI', 'nama' => '', 'jenjang' => 'S1',
        ])->assertSessionHasErrors('nama');
        $html = $this->get($edit)->assertOk()->getContent();
        preg_match('/<input[^>]*type="checkbox"[^>]*name="aktif"[^>]*>/', $html, $match);
        $this->assertNotEmpty($match);
        $this->assertStringNotContainsString('checked', $match[0]);
        $this->assertTrue($program->fresh()->aktif);
    }
}
